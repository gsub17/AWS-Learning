# AWS Cloud 3 – Tier Architecture Application Diagram

Three tier architecture 

1. Presentation Tier - the Amazon app web page 
2. Business / Logic Tier - when we add anything in the cart , the computation of the cost happen here
3. Database Tier - every data need to be store somewhere


AWS Services Used:

1. VPC 
2. Subnet
3. Internet Gateway
4. Nat Gateways
5. Route Tables
6. Elastic Load Balancer
7. Auto Scaling Groups
8. CloudFront - Part of presentation tier, deliver web pages to end user.
9. EC2/ECS - Part of Business / logic tier.
10. RDS - it is part of the database tier
11. Route 53
12. WAF




1. To create private service of your application we need VPC. It create isolation for entire application.
2. The presentation , business and database tier will come inside of VPC.
3. How the user will route through, to get access of any website.  Here comes the route 53 , with it help your application hosted on AWS can be access by outside world. Route 53 knows which VPC it need to connect.
4. However the VPC is a private entity and the request coming from outside is public . So we need a internet gate way in btw of VPC and route 53.
5. Cloud front present in the presentation tier will contain all the UI images , contents.
6. Public subnet will access of the presentation and business tier and we don't want public to have access of database tier so it belongs to Private subnet.
7. Then we have EC2 in business tier , here to maintain load equally distribute we need to have a load balancer here. the traffic coming from CloudFront is then comes to elastic load balancer which distribute the traffic according to availability of ec2.
8. Since the EC2 are present in the public subnet and the RDS are present inside of private subnet , so we needed nat gateway between them.


